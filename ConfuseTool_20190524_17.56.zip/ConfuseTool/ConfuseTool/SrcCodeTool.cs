﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfuseTool
{
    /// <summary>
    /// 用于对cs源码文件进行处理，解析其中所有函数方法名、变量名、函数变量名。
    /// 用法：List<string> tmp = SrcCodeTool.GetFileCodeNames(files);
    /// </summary>
    public static class SrcCodeTool
    {
        #region 获取代码块数据

        /// <summary>
        /// 获取所有files文件中的函数方法、变量名称信息
        /// </summary>
        public static List<string> GetFileCodeNames(string[] files)
        {
            List<string> tmp = new List<string>();

            foreach (string file in files)
            {
                string data = FileProcess.fileToString(file);
                List<string> fileTmp = getFieldNameList(data);

                tmp.AddRange(fileTmp);
            }

            return tmp;
        }

        /// <summary>
        /// 获取申明的函数变量名称
        /// </summary>
        public static List<string> getFieldNameList(string data)
        {
            data = removeNoteInfo(data);    // 移除data上的注释信息
            string nameSpaceData = getMatchData(data, "namespace");                 // 获取nameSpace数据
            List<string> classDataList = getMatchDataList(nameSpaceData, "class");  // 获取class数据

            List<string> nameList = new List<string>();
            foreach (string classData0 in classDataList)
            {
                string classData = removeFuncBody(classData0);                      // 移除类函数方法体
                List<string> tmpList = getFunctionDeclearNames(classData);          // 获取申明的函数变量名称
                nameList.AddRange(tmpList);

                List<string> tmpList2 = getVarribleNames(classData);                // 获取声明变量名称
                nameList.AddRange(tmpList2);
            }

            return nameList;
        }

        /// <summary>
        /// 解析所有行变量如： Button button1, button2; —>button1 button2 
        /// </summary>
        private static  List<string> getVarribleNames(string data)
        {
            List<string> list = new List<string>();

            string[] lines = data.Replace("\r\n", "\n").Split('\n');
            foreach (string str0 in lines)
            {
                string str = str0.Trim();
                if (str.EndsWith(";"))   // 变量所在行
                {
                    str = str.Substring(0, str.Length - 1);
                    string[] varribles = str.Split(',');
                    foreach (string v0 in varribles)
                    {
                        string v = v0.Trim();
                        if (!v.Equals(""))
                        {
                            string name = getName(v);
                            if (!list.Contains(name)) list.Add(name);
                        }
                    }
                }
            }

            return list;
        }

        /// <summary>
        /// 获取data中，函数方法名、属性名
        /// </summary>
        private static  List<string> getFunctionDeclearNames(string data)
        {
            List<string> list = new List<string>();

            int startIndex = data.IndexOf("(");
            while (startIndex != -1)
            {
                int endIndex = getMatchIndex(data, startIndex, '(', ')');
                if (endIndex == -1)
                {
                    startIndex = data.IndexOf("(", startIndex + 1);
                    continue;
                }

                // 获取函数名称，解析“ getFunctionDeclear(”
                string startStr = data.Substring(0, startIndex).Trim();
                if (startStr.Contains(" "))
                {
                    string funName = getName(startStr);
                    if (!funName.Equals("") && !list.Contains(funName)) list.Add(funName);

                    //if (funName.Equals("matchE"))
                    //    funName += "";
                }

                // 获取属性字段中的名称(String data, String filePath, Encoding encoding = null)
                startIndex = startIndex + 1;
                string AttrStr = data.Substring(startIndex, endIndex - startIndex);
                string[] A = AttrStr.Split(',');
                foreach (string a in A)
                {
                    string attrName = getName(a);
                    if (!attrName.Equals("") && !list.Contains(attrName)) list.Add(attrName);

                    //if (attrName.Equals("matchE"))
                    //    attrName += "";
                }

                //startIndex = getMatchIndex(data, startIndex, '{', '}') + 1;
                startIndex = data.IndexOf("(", startIndex);
            }

            return list;
        }

        /// <summary>
        /// 获取属性字段名， 如： Encoding encoding = null —> encoding
        /// </summary>
        private static  string getName(string Str)
        {
            string name = "";

            while (Str.Contains("= "))
            {
                Str = Str.Replace("= ", "=");
            }

            int indexE = -1;
            int startIndex = -1;
            if (Str.Contains("=")) indexE = Str.LastIndexOf("=");
            if (Str.Contains(" ")) startIndex = Str.LastIndexOf(" ");

            if (indexE != -1 && startIndex != -1 && indexE > startIndex)
            {
                Str = Str.Substring(0, indexE).Trim();
                return getName(Str);
            }
            else if (startIndex != -1) name = Str.Substring(startIndex + 1).Trim();

            return name;
        }

        /// <summary>
        /// 在data中获取所有 name{ XXX }，之间的数据信息
        /// </summary>
        private static  List<string> getMatchDataList(string data, string name, char matchS = '{', char matchE = '}')
        {
            List<string> list = new List<string>();

            int index = data.IndexOf(name);
            if (index == -1) return list;

            while (index != -1)
            {
                int matchIndex = getMatchIndex(data, index);
                string classData = getMatchData(data, name).Trim();         // 获取class数据
                if (!classData.Equals(""))
                {
                    if (!list.Contains(classData)) list.Add(classData);     // 记录class数据
                }

                data = data.Substring(matchIndex + 1);                      // 获取剩余数据    

                index = data.IndexOf(name);
                if (index == -1) return list;
            }

            return list;
        }


        /// <summary>
        /// 在data中获取与首个{ 匹配的 }，之间的数据信息
        /// </summary>
        private static  string getMatchData(string data, string name, char matchS = '{', char matchE = '}')
        {
            int index = data.IndexOf(name);
            if (index == -1) return "";
            else
            {
                index = index + name.Length;
                StringBuilder sb = new StringBuilder();

                int count = 0;
                bool isStart = false;

                char[] Array = data.ToArray();
                for (int i = index; i < Array.Length; i++)
                {
                    char c = Array[i];

                    if (c == matchS)
                    {
                        count++;
                        if (!isStart)
                        {
                            isStart = true;
                            continue;   // 忽略首个{
                        }
                    }
                    else if (c == matchE) count--;

                    if (count > 0) sb.Append(c + "");
                    if (isStart && count == 0) break;
                }

                return sb.ToString();
            }
        }

        /// <summary>
        /// 从startIndex处开始，获取与首个{ 匹配的 } 对应的索引位置
        /// </summary>
        private static  int getMatchIndex(string data, int startIndex, char matchS = '{', char matchE = '}')
        {
            int count = 0;
            bool isStart = false;

            char[] Array = data.ToArray();
            for (int i = startIndex; i < Array.Length; i++)
            {
                char c = Array[i];

                if (c == matchS)
                {
                    count++;
                    if (!isStart)
                    {
                        isStart = true;
                        continue;   // 忽略首个{
                    }
                }
                else if (c == matchE) count--;

                if (isStart && count == 0) return i;
            }

            return -1;
        }

        #endregion


        #region 移除函数body部分

        private static  string removeFuncBody(string data)
        {
            int indexS = data.IndexOf("{");
            while (indexS != -1)
            {
                int indexE = getMatchIndex(data, indexS);
                if (indexE != -1)
                {
                    data = data.Substring(0, indexS) + data.Substring(indexE + 1);
                }

                indexS = data.IndexOf("{");
            }
            data = removeEmptyLine_Override(data);

            return data;
        }

        /// <summary>
        /// 移除data中override行、空行
        /// </summary>
        private static  string removeEmptyLine_Override(string data)
        {
            StringBuilder b = new StringBuilder();

            string[] Array = data.Replace("\r\n", "\n").Split('\n');
            foreach (string str0 in Array)
            {
                string str = str0.Trim();
                if (str.Equals("") || str.Contains(" override ") || str.StartsWith("override ")) continue;

                b.AppendLine(str);
            }

            return b.ToString();
        }

        #endregion


        #region 注释行、空行 移除

        /// <summary>
        /// 移除注释行
        /// </summary>
        private static  string removeNoteInfo(string data)
        {
            string[] lines = data.Replace("\r\n", "\n").Split('\n');
            List<string> list = new List<string>(lines);

            list = RemoveNoteInfo(list, true);
            StringBuilder strb = new StringBuilder();
            foreach (string line in list)
            {
                strb.AppendLine(line);
            }
            return strb.ToString();
        }

        /// <summary>
        /// 移除注释行
        /// </summary>
        private static  List<string> RemoveNoteInfo(List<string> list, bool removequte = false)
        {
            bool matchMode = false;
            List<string> tmp = new List<string>();

            foreach (string line0 in list)
            {
                string line = line0.Trim();

                // 清空引号之间的字符
                if (removequte)
                {
                    while (line.Contains("\""))
                    {
                        int indexS = line.IndexOf("\"") + 1;
                        int indexE = line.IndexOf("\"", indexS);
                        if (indexE != -1)
                        {
                            string tmpS = line.Substring(indexS, indexE - indexS);
                            while (tmpS.EndsWith("\\") && !tmpS.EndsWith("\\\\"))
                            {
                                indexE = line.IndexOf("\"", indexE + 1);
                                tmpS = line.Substring(indexS, indexE - indexS);
                            }

                            line = line.Substring(0, indexS - 1) + line.Substring(indexE + 1);
                        }
                        else break;
                    }
                }

                // 剔除行内注释块
                while (line.Contains("/*") && line.Contains("*/"))
                {
                    int indexS = line.IndexOf("/*");
                    int indexE = line.IndexOf("*/");
                    line = line.Substring(0, indexS) + line.Substring(indexE + "*/".Length);
                }

                if (matchMode)
                {
                    if (line.Contains("*/"))
                    {
                        matchMode = false;
                        line = line.Substring(line.IndexOf("*/") + 2);
                    }
                    else continue;
                }

                if (line.StartsWith("//") || line.StartsWith("#region") || line.StartsWith("#endregion")) continue;
                else if (line.Contains("//")) line = line.Substring(0, line.IndexOf("//"));
                else if (line.Contains("/*"))
                {
                    matchMode = true;
                    line = line.Substring(0, line.IndexOf("/*"));
                }

                line = line.Trim();
                if (!line.Equals("")) tmp.Add(line);
            }

            return tmp;
        }

        #endregion


    }
}
