﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfuseTool
{
    /// <summary>
    /// 拖拽处理
    /// </summary>
    public class DragDropTool
    {
        /// <summary>
        /// DragEnter
        /// </summary>
        public static void Form_DragEnter(object sender, DragEventArgs e)
        {
            dragEnter(e);
        }

        /// <summary>
        /// DragDrop
        /// </summary>
        public static string[] Form_DragDrop(object sender, DragEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.Text = dragDrop(e);                 // 获取拖入的文件
            string[] files = textBox.Text.Split(';');
            // 其他处理逻辑

            return files;
        }

        /// <summary>
        /// 获取files文件或目录列表下的所有文件信息
        /// </summary>
        public static string[] GetSubFiles(Array files)
        {
            string AllFiles = toSubDirFileNames(files);
            string[] SubFiles = AllFiles.Split(';');

            return SubFiles;
        }

        # region 文件拖拽

        /// <summary>  
        /// 文件拖进事件处理：  
        /// </summary>  
        private static void dragEnter(DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))    //判断拖来的是否是文件  
                e.Effect = DragDropEffects.Link;                //是则将拖动源中的数据连接到控件  
            else e.Effect = DragDropEffects.None;
        }

        /// <summary>  
        /// 文件放下事件处理：  
        /// 放下, 另外需设置对应控件的 AllowDrop = true;   
        /// 获取的文件名形如 "d:\1.txt;d:\2.txt"  
        /// </summary>  
        private static string dragDrop(DragEventArgs e)
        {
            Array file = (System.Array)e.Data.GetData(DataFormats.FileDrop);//将拖来的数据转化为数组存储
            return toSubDirFileNames(file);
        }


        // 获取所有files目录下的所有文件，转化为单个串
        private static string toSubDirFileNames(Array files)
        {
            StringBuilder filesName = new StringBuilder("");

            foreach (object I in files)
            {
                string str = I.ToString();

                System.IO.FileInfo info = new System.IO.FileInfo(str);
                //若为目录，则获取目录下所有子文件名  
                if ((info.Attributes & System.IO.FileAttributes.Directory) != 0)
                {
                    str = getAllFiles(str);
                    if (!str.Equals("")) filesName.Append((filesName.Length == 0 ? "" : ";") + str);
                }
                //若为文件，则获取文件名  
                else if (System.IO.File.Exists(str))
                    filesName.Append((filesName.Length == 0 ? "" : ";") + str);
            }

            return filesName.ToString();
        }


        #region 待混淆源码文件和exe文件路径载入


        /// <summary>
        /// 拖动工程目录到sender
        /// </summary>
        public static string Form_DragDropSlnDir(object sender, DragEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.Text = dragDropSlnDir(e);                 // 获取拖入的文件

            return textBox.Text;
        }

        /// <summary>  
        /// 文件放下事件处理：  
        /// 放下, 另外需设置对应控件的 AllowDrop = true;   
        /// 获取的文件名形如 "d:\1.txt;d:\2.txt"  
        /// </summary>  
        private static string dragDropSlnDir(DragEventArgs e)
        {
            Array file = (System.Array)e.Data.GetData(DataFormats.FileDrop);//将拖来的数据转化为数组存储
            return getSlnDir(file);
        }

        /// <summary>
        /// 获取所有files目录下首个包含.sln文件的目录的同名子目录
        /// </summary>
        private static string getSlnDir(Array files)
        {
            foreach (object I in files)
            {
                string str = I.ToString();
                if(Directory.Exists(str))
                {
                    string[] subFiles = Directory.GetFiles(str);        // 获取子文件名
                    foreach(string subFile in subFiles)
                    {
                        if (subFile.EndsWith(".sln"))
                        {
                            string dirName = Path.GetFileNameWithoutExtension(subFile);

                            string subDirName = str + "\\" + dirName;
                            if (Directory.Exists(subDirName)) return subDirName;
                        }
                    }
                }
                else if (File.Exists(str) && str.ToLower().EndsWith(".exe"))
                {
                    return str;
                }
            }

            return "";
        }

        /// <summary>
        /// 获取Dir目录下所有CS文件路径信息
        /// </summary>
        public static List<string> getSubCS(string Dir)
        {
            List<string> files = new List<string>();
            if(Directory.Exists(Dir))
            {
                string[] subFiles = Directory.GetFiles(Dir);
                foreach(string subFile in subFiles)
                {
                    if (subFile.ToLower().EndsWith(".cs")) files.Add(subFile);
                }

                string[] subDirs = Directory.GetDirectories(Dir);
                foreach (string subDir in subDirs)
                {
                    // 忽略特定的目录
                    DirectoryInfo dirInfo = new DirectoryInfo(subDir);
                    string subDirName = dirInfo.Name;
                    //string subDirName = Path.GetDirectoryName(subDir);

                    List<string> ignodir = new List<string>() { "bin", "obj", "Properties", "Resources" };
                    if (ignodir.Contains(subDirName)) continue;

                    // 获取当前目录下的cs文件
                    List<string> subList = getSubCS(subDir);
                    files.AddRange(subList);
                }

            }
            return files;
        }

        /// <summary>
        /// 获取Dir目录下Exe文件所在路径
        /// </summary>
        public static string getExePath(string Dir)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(Dir);
            string dirName = dirInfo.Name;
            //string dirName = Path.GetDirectoryName(Dir);

            string exePath = Dir + "\\bin\\Debug\\" + dirName + ".exe";
            if (File.Exists(exePath)) return exePath;
            else return "";
        }

        #endregion


        /// <summary>  
        /// 判断path是否为目录  
        /// </summary>  
        private static bool IsDirectory(String path)
        {
            System.IO.FileInfo info = new System.IO.FileInfo(path);
            return (info.Attributes & System.IO.FileAttributes.Directory) != 0;
        }

        /// <summary>  
        /// 获取目录path下所有子文件名  
        /// </summary>  
        private static string getAllFiles(String path)
        {
            StringBuilder str = new StringBuilder("");
            if (System.IO.Directory.Exists(path))
            {
                //所有子文件名  
                string[] files = System.IO.Directory.GetFiles(path);
                foreach (string file in files)
                    str.Append((str.Length == 0 ? "" : ";") + file);

                //所有子目录名  
                string[] Dirs = System.IO.Directory.GetDirectories(path);
                foreach (string dir in Dirs)
                {
                    string tmp = getAllFiles(dir);  //子目录下所有子文件名  
                    if (!tmp.Equals("")) str.Append((str.Length == 0 ? "" : ";") + tmp);
                }
            }
            return str.ToString();
        }

        # endregion
    }

}
