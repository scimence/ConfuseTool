﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfuseTool
{
    /// <summary>
    /// 对源码文件中的字符串进行加密混淆
    /// </summary>
    class StringTool
    {
        /// <summary>
        /// 合并strList中的所有字符串为单个字符串
        /// </summary>
        public static string ToEncodeSingleStr(List<string> strList, string EncodSubStr = "", List<string> list=null)
        {
            // 对各字符串分别加密
            list = new List<string>();
            foreach (string str in strList)
            {
                EncodSubStr = Encoder.EncodeAlphabet(str);
                list.Add(EncodSubStr);
            }

            // 合并为单个串
            EncodSubStr = toSingleStr(list);
            return Encoder.EncodeAlphabet(EncodSubStr);    // 二次加密
        }

        /// <summary>
        /// 从加密的字符串中解析数据信息
        /// </summary>
        public static List<string> ToDecodeStrList(string encodeSingleStr, List<string> list = null, string[] StringDatasA = null)
        {
            encodeSingleStr = Encoder.DecodeAlphabet(encodeSingleStr);      // 解密
            StringDatasA = encodeSingleStr.Split((char)(',' - 8));          // 分割 '$'

            // 对各字符串分别解密
            list = new List<string>();
            foreach (string str in StringDatasA)
            {
                encodeSingleStr = Encoder.DecodeAlphabet(str);
                list.Add(encodeSingleStr);
            }
            return list;
        }


        /// <summary>
        /// 选取一个.cs文件索引值
        /// </summary>
        public static int getCsIndex(string[] files)
        {
            int index = -1;
            if (files != null)
            {
                foreach (string file in files)
                {
                    if (file.EndsWith(".cs") || file.EndsWith(".java")) index++;
                }
            }
            if (index > 2) index = index - 1;
            return index;
        }

        /// <summary>
        /// 对给定的文件进行混淆
        /// </summary>
        public static void ProcessLogic(string path, int index = 0, bool AddEncodeClass = false)
        {
            string data = FileTool.fileToString(path);
            data = ConfuseStringProcess(data, index);
            if (AddEncodeClass)
            {
                string strData = GenerateEncoderClass();    // 生成字符串解析类
                data = AddDataInStart(data, strData);       // 添加解析类至源码
            }
            FileTool.SaveProcess(data, path, null, true);
        }

        /// <summary>
        /// 源码字符串混淆逻辑
        /// </summary>
        private static string ConfuseStringProcess(string soucrceCode, int index = 0)
        {
            // 解析所有字符串信息， 并替换字符串信息
            List<string> strList = new List<string>();

            StringBuilder Str = new StringBuilder();

            // 替换@形式开头的字符串为标准格式,如： @"渠道计费包\0000843\" -> "渠道计费包\\0000843\\"
            while (soucrceCode.Contains("@\"") && soucrceCode.Contains("\""))
            {
                int start = soucrceCode.IndexOf("@\"") + 2;
                if (start == -1) break;

                int end = soucrceCode.IndexOf("\"", start + 1);
                if (end == -1) break;

                string key = soucrceCode.Substring(start, end - start );
                string value = key.Replace("\\", "\\\\");
                soucrceCode = soucrceCode.Replace("@\"" + key + "\"", "\"" + value + "\"");
            }

            List<string> appendLines = new List<string>();

            string[] lines = soucrceCode.Replace("\r\n", "\n").Split('\n'); // 获取所有行
            foreach (string line in lines)
            {
                string lineData = line;
                if (lineData.Trim().StartsWith("//")) continue;     // 忽略注释行
                
                int start = 0, end = -1;
                while (lineData != null && start < lineData.Length)
                {
                    start = lineData.IndexOf("\"", start);
                    if (start == -1) break;

                    end = lineData.IndexOf("\"", start + 1);
                    if (end == -1) break;

                    bool nextProcess = true;
                    string subStr = lineData.Substring(start + 1, end - start - 1);
                    while (ContainsTransMeaningChar(subStr))        // 若substr中存在转义字符，则获取下一个引号位置
                    {
                        end = lineData.IndexOf("\"", end + 1);
                        if (end == -1)
                        {
                            nextProcess = false;
                            break;
                        }
                        else subStr = lineData.Substring(start + 1, end - start - 1);
                    }

                    // "        static void Main(String[] args, String tmp =\"test\", String tmp =\"test2\")"
                    if (nextProcess)
                    {
                        subStr = trimTrasMeaningChar(subStr);   // 移除转义字符，还原为原有串
                        //if (subStr.Contains("\\\\")) subStr = subStr.Replace("\\\\", "\\");
                        //if (subStr.Contains("\\\"")) subStr = subStr.Replace("\\\"", "\"");

                        string EncodSubStr = Encoder.EncodeAlphabet(subStr);            // 字符串加密

                        if (!strList.Contains(EncodSubStr)) strList.Add(EncodSubStr);   // 记录字符串信息
                        int StrIndex = strList.IndexOf(EncodSubStr);                    // 获取索引值

                        // 替换字符串为函数解析
                        string Value = "Decodex" + index + "(" + StrIndex + ")";

                        string lineDataStart = lineData.Substring(0, start).Trim();
                        string lineDataEnd = lineData.Substring(end + 1);
                        if (lineDataStart.Contains("(") && lineDataEnd.Contains(")") && (lineDataStart.Contains("public") || lineDataStart.Contains("private") || lineDataStart.Contains("void")) )
                        {
                            lineData = lineData.Substring(0, start) + " null" + lineData.Substring(end + 1);  
                            
                            // 添加变量初始值默认行
                            string name = getName(lineDataStart);
                            string newLine = "if("+ name+ " == null) " + name+ " = " + Value +";";
                            appendLines.Add(newLine);
                        }
                        else lineData = lineData.Substring(0, start) + Value + lineData.Substring(end + 1);  

                        end = start + Value.Length;
                    }

                    start = end + 1;
                }

                // 在方法体起始位置附加行
                if (appendLines.Count > 0 && lineData.Contains("{"))
                {
                    int indexS = lineData.IndexOf("{");

                    string lineDataEnd = lineData.Substring(indexS + 1);
                    lineData = lineData.Substring(0, indexS + 1);
                    foreach(string linestr in appendLines)
                    {
                        lineData += "\r\n\t" + linestr;
                    }
                    lineData += "\r\n" + lineDataEnd;

                    appendLines.Clear();
                }

                Str.AppendLine(lineData);
            }

            soucrceCode = Str.ToString();

            // 合并字符串信息为单个串
            string strData = toSingleStr(strList);
            if(!strData.Equals("")) strData = GenerateDecode(strData, index);           // 生成字符串解析逻辑

            // 添加字符串信息值源码
            string data = AddDataInClass(soucrceCode, strData);
            return data;
        }


        /// <summary>
        /// 获取属性字段名， 如： Encoding encoding = null —> encoding
        /// </summary>
        private static string getName(string Str)
        {
            string name = "";

            while (Str.Contains("= "))
            {
                Str = Str.Replace("= ", "=");
            }

            int indexE = -1;
            int startIndex = -1;
            if (Str.Contains("=")) indexE = Str.LastIndexOf("=");
            if (Str.Contains(" ")) startIndex = Str.LastIndexOf(" ");

            if (indexE != -1 && startIndex != -1 && indexE > startIndex)
            {
                Str = Str.Substring(0, indexE).Trim();
                return getName(Str);
            }
            else if (startIndex != -1) name = Str.Substring(startIndex + 1).Trim();

            return name;
        }

        /// <summary>
        /// 移除str中的转义字符,保留原有字符信息
        /// </summary>
        private static string trimTrasMeaningChar(string str)
        {
            List<char> list = new List<char>();
            for (int i = str.Length - 1; i >= 0; i--)
            {
                bool isTransChar = false;
                char C = str[i];

                if (i - 1 >= 0 && str[i - 1] == '\\') isTransChar = true;
                if (isTransChar)
                {
                    if (C == 'a') C = '\a';
                    if (C == 'b') C = '\b';
                    if (C == 'f') C = '\f';
                    if (C == 'n') C = '\n';
                    if (C == 'r') C = '\r';
                    if (C == 't') C = '\t';
                    if (C == 'v') C = '\v';
                    if (C == '0') C = '\0';

                    i--;  // 跳过转义字符
                }

                list.Insert(0, C);
            }
            return new string(list.ToArray());
        }

        /// <summary>
        /// 判断str的结尾处是否存在转义字符 \
        /// </summary>
        private static bool ContainsTransMeaningChar(string str)
        {
            bool contain = false;
            for(int i=str.Length-1; i>=0; i--)
            {
                if (str[i] == '\\') contain = !contain;
                else break;
            }
            return contain;
        }

        /// <summary>
        /// 在代码类开始处添加字符串解析方法
        /// </summary>
        private static string AddDataInStart(string soucrceCode, string appends)
        {
            if (appends.Equals("")) return soucrceCode;

            int index = soucrceCode.IndexOf("{");

            string header = soucrceCode.Substring(0, index + 1);
            string reminder = soucrceCode.Substring(index + 1);

            string data = header + "\r\n" + appends + "\r\n" + reminder;
            return data;
        }

        /// <summary>
        /// 在代码类开始处添加字符串解析方法
        /// </summary>
        private static string AddDataInClass(string soucrceCode, string appends)
        {
            if (!appends.Equals(""))
            {
                List<int> indexs = getClassIndex(soucrceCode);
                soucrceCode = AddData(soucrceCode, appends, indexs);
            }

            return soucrceCode;
        }

        /// <summary>
        /// 获取源码各个类起始位置
        /// </summary>
        private static List<int> getClassIndex(string soucrceCode)
        {
            List<int> list = new List<int>();
            int index = soucrceCode.IndexOf(" class ");
            while (index != -1)
            {
                index = soucrceCode.IndexOf("{", index + 1);
                if (index != -1 && !list.Contains(index + 1))
                {
                    list.Add(index + 1);
                }
                index = soucrceCode.IndexOf(" class ", index);  // 获取下一个类位置
            }

            return list;
        }

        /// <summary>
        /// 在源码的指定位置插入数据
        /// </summary>
        private static string AddData(string soucrceCode, string appends, List<int> indexs)
        {
            for(int i=indexs.Count-1; i>=0; i--)
            {
                int index = indexs[i];

                string header = soucrceCode.Substring(0, index);
                string reminder = soucrceCode.Substring(index);

                soucrceCode = header + "\r\n" + appends + "\r\n" + reminder;
            }
            return soucrceCode;
        }

        /// <summary>
        /// 合并strList中的所有字符串为单个字符串
        /// </summary>
        private static string toSingleStr(List<string> strList)
        {
            StringBuilder Str = new StringBuilder();

            char c = (char)('+' - 7);            // '$'
            foreach (string s in strList)
                Str.Append(s + c);


            return strList.Count == 0 ? "" : Str.ToString();
        }

        

        /// <summary>
        /// 生成字符串解析方法
        /// </summary>
        private static string GenerateDecode(string strData, int index)
        {
            StringBuilder Str = new StringBuilder();

            string Decodex = "Decodex" + index;
            string StringDatas = "StringDatas" + (index + 2);
            string StringDatasA = "StringDatasA" + (index+1);
            string Index = "index" + (index + 3);


            Str.AppendLine("        private static string StringDatas = \"" + strData + "\";");
            Str.AppendLine("        private static string[] StringDatasA = null;");
            Str.AppendLine("        ");
            Str.AppendLine("        private static string Decodex(int index)");
            Str.AppendLine("        {");
            Str.AppendLine("            if (StringDatasA == null) StringDatasA = StringDatas.Split((char)(',' - 8));    // '$'");
            Str.AppendLine("            string data = StringDatasA[index];");
            Str.AppendLine("            data = EncoderXXX.DecodeAlphabet(data);");
            Str.AppendLine("            return data;");
            Str.AppendLine("        }");

            string data = Str.ToString();
            data = data.Replace("index", Index);
            data = data.Replace("Decodex", Decodex);
            data = data.Replace("StringDatas", StringDatas);
            data = data.Replace("StringDatasA", StringDatasA);

            return data;
        }


        //private static string StringDatas = "";
        //private static string[] StringDatasA = null;

        ///// <summary>
        ///// 获取指定索引的字符串
        ///// </summary>
        //public static string Decodex(int index)
        //{
        //    if (StringDatasA == null) StringDatasA = StringDatas.Split((char)(',' - 8));    // '$'
        //    string data = StringDatasA[index];
        //    data = Encoder.DecodeAlphabet(data);
        //    return data;
        //}


        /// <summary>
        /// 生成字符串解析方法
        /// </summary>
        private static string GenerateEncoderClass()
        {
            StringBuilder Str = new StringBuilder();

            Str.AppendLine("    public class EncoderXXX");
            Str.AppendLine("    {");
            Str.AppendLine("        /// <summary> ");
            Str.AppendLine("        /// 解析字母字符串");
            Str.AppendLine("        /// </summary>");
            Str.AppendLine("        public static string DecodeAlphabet(string data)");
            Str.AppendLine("        {");
            Str.AppendLine("            byte[] B = new byte[data.Length / 2];");
            Str.AppendLine("            char[] C = data.ToCharArray();");
            Str.AppendLine("            for (int i = 0; i < C.Length; i += 2)");
            Str.AppendLine("            {");
            Str.AppendLine("                byte b = ToByte(C[i], C[i + 1]);");
            Str.AppendLine("                B[i / 2] = b;");
            Str.AppendLine("            }");
            Str.AppendLine("            return System.Text.Encoding.UTF8.GetString(B);");
            Str.AppendLine("        }");
            Str.AppendLine("        ");
            Str.AppendLine("        /// <summary>  ");
            Str.AppendLine("        /// 每两个字母还原为一个字节");
            Str.AppendLine("        /// </summary>");
            Str.AppendLine("        private static byte ToByte(char a1, char a2)");
            Str.AppendLine("        {");
            Str.AppendLine("            return (byte)((a1 - 'a') * 16 + (a2 - 'a'));");
            Str.AppendLine("        }");
            Str.AppendLine("    }");
            Str.AppendLine("        ");

            return Str.ToString();
        }

    }


    //public class Encoder2
    //{
    //    /// <summary>  
    //    /// 解析字母字符串  
    //    /// </summary>  
    //    public static string DecodeAlphabet(string data)
    //    {
    //        byte[] B = new byte[data.Length / 2];
    //        char[] C = data.ToCharArray();
    //        for (int i = 0; i < C.Length; i += 2)
    //        {
    //            byte b = ToByte(C[i], C[i + 1]);
    //            B[i / 2] = b;
    //        }
    //        return System.Text.Encoding.UTF8.GetString(B);
    //    }

    //    /// <summary>  
    //    /// 每两个字母还原为一个字节  
    //    /// </summary>  
    //    private static byte ToByte(char a1, char a2)
    //    {
    //        return (byte)((a1 - 'a') * 16 + (a2 - 'a'));
    //    }
    //}  

    public class Encoder  
    {  
        public static void example()  
        {  
            String data = "test encode";  
            string encode = Encode(data);  
            string decode = Decode(encode);  
            bool b = data.Equals(decode);  
            bool b2 = b;  
        }  
  
        /// <summary>  
        /// 转码data为全字母串，并添加前缀  
        /// </summary>  
        public static string Encode(string data)  
        {  
            string str = data;  
            if (!data.StartsWith("ALPHABETCODE@"))  
            {  
                str = "ALPHABETCODE@" + EncodeAlphabet(data);  
            }  
            return str;  
        }  
  
  
        /// <summary>  
        /// 解析字母串为原有串  
        /// </summary>  
        public static string Decode(string data)  
        {  
            string str = data;  
            if (data.StartsWith("ALPHABETCODE@"))  
            {  
                str = DecodeAlphabet(data.Substring("ALPHABETCODE@".Length));  
            }  
            return str;  
        }  
 
 
        # region 字符串字母编码逻辑  
  
        /// <summary>  
        /// 转化为字母字符串  
        /// </summary>  
        public static string EncodeAlphabet(string data)  
        {  
            byte[] B = Encoding.UTF8.GetBytes(data);  
            return ToStr(B);  
        }  
  
        /// <summary>  
        /// 每个字节转化为两个字母  
        /// </summary>  
        private static string ToStr(byte[] B)  
        {  
            StringBuilder Str = new StringBuilder();  
            foreach (byte b in B)  
            {  
                Str.Append(ToStr(b));  
            }  
            return Str.ToString();  
        }  
  
        private static string ToStr(byte b)  
        {  
            return "" + ToChar(b / 16) + ToChar(b % 16);  
        }  
  
        private static char ToChar(int n)  
        {  
            return (char)('a' + n);  
        }  
  
        /// <summary>  
        /// 解析字母字符串  
        /// </summary>  
        public static string DecodeAlphabet(string data)  
        {  
            byte[] B = new byte[data.Length / 2];  
            char[] C = data.ToCharArray();  
  
            for (int i = 0; i < C.Length; i += 2)  
            {  
                byte b = ToByte(C[i], C[i + 1]);  
                B[i / 2] = b;  
            }  
  
            return Encoding.UTF8.GetString(B);  
        }  
  
        /// <summary>  
        /// 每两个字母还原为一个字节  
        /// </summary>  
        private static byte ToByte(char a1, char a2)  
        {  
            return (byte)((a1 - 'a') * 16 + (a2 - 'a'));  
        }  
 
        # endregion  
  
    }  
}
