﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfuseTool
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            ApplicationException.Run(call, args);     // 调用异常信息捕获类，进行异常信息的捕获

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form2());
        }

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        static void call(string[] args)
        {
            if (args == null || args.Length == 0)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            }
            else
            {
                string[] files = DragDropTool.GetSubFiles(args);

                int index = 100;
                int LastCs = StringTool.getCsIndex(files);
                foreach (string file in files)
                {
                    if (file.EndsWith(".cs") || file.EndsWith(".java"))
                    {
                        StringTool.ProcessLogic(file, index++, LastCs == index - 100);  // 源码字符串混淆,选取一个源码文件中添加字符串解析类
                    }
                    else if (file.EndsWith(".exe") || file.EndsWith(".dll"))
                    {
                        RenameTool.ProcessLogic(file);
                    }
                }

                //foreach (string file in files) RenameTool.ProcessLogic(file);
            }
        }
    }
}
