﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfuseTool
{
    public partial class Form1 : Form
    {
        ConfuseExe confuse = null;

        public Form1()
        {
            InitializeComponent();
            loadExceptList();
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            DragDropTool.Form_DragEnter(sender, e);
        }

        private void Form1_DragDropProject(object sender, DragEventArgs e)
        {
            string path = DragDropTool.Form_DragDropSlnDir(sender, e);

            if(path.EndsWith(".exe"))
            {
                button.Enabled = false;

                confuse = new ConfuseExe(path);     // 载入待混淆文件信息
            }
            else
            {
                button.Enabled = true;

                List<string> csFiles = DragDropTool.getSubCS(path);
                if (csFiles.Count == 0)
                {
                    MessageBox.Show("工程目录下未找到源码文件 \r\n" + path);
                }

                string exePath = DragDropTool.getExePath(path);
                if (!System.IO.File.Exists(exePath))
                {
                    MessageBox.Show("请先运行工程，编译生成.exe \r\n" + path);
                }

                List<string> confuseList = SrcCodeTool.GetFileCodeNames(csFiles.ToArray());
                confuse = new ConfuseExe(exePath, confuseList); // 载入待混淆文件信息
            }

            confuse.showInList(listBoxAll, listBoxConfuse);     // 显示所有字段、待混淆字段信息
            autoClearExceptList();                              // 自动剔除默认不混淆字段
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = DragDropTool.Form_DragDrop(sender, e);
            //foreach (string file in files) RenameTool.Process(file, checkBox.Checked);

            int index = 100;
            int LastCs = StringTool.getCsIndex(files);
            foreach (string file in files)
            {
                if (file.EndsWith(".cs") || file.EndsWith(".java"))
                {
                    StringTool.ProcessLogic(file, index + 1, LastCs == index++ - 100);  // 源码字符串混淆,选取一个源码文件中添加字符串解析类
                }
                else if (file.EndsWith(".exe") || file.EndsWith(".dll"))
                {
                    confuse = new ConfuseExe(file);                     // 载入待混淆文件信息
                    confuse.showInList(listBoxAll, listBoxConfuse);     // 显示所有字段、待混淆字段信息
                    autoClearExceptList();                              // 自动剔除默认不混淆字段
                    break;
                }
            }
        }

        /// <summary>
        /// 根据混淆字段配置，进行名称混淆
        /// </summary>
        private void button_Click(object sender, EventArgs e)
        {
            if (confuse != null)
            {
                confuse.confuseList = getList(listBoxConfuse);
                confuse.Confuse(checkBox.Checked);
            }
        }

        /// <summary>
        /// 对.cs文件进行源码混淆
        /// </summary>
        private void buttonStr_Click(object sender, EventArgs e)
        {
            //string filePath = "G:\\sc\\MainFrom.cs";
            //StringTool.ProcessLogic(filePath, 0, true);

            string path = textBoxPath.Text.Trim();
            List<string> csFiles = DragDropTool.getSubCS(path);         // 获取path路径下的cs文件
            if (csFiles.Count == 0)
            {
                MessageBox.Show("工程目录下未找到源码文件 \r\n" + path);
            }
            else
            {
                string[] files = csFiles.ToArray();

                int index = 100;
                int LastCs = StringTool.getCsIndex(files);
                foreach (string file in files)
                {
                    if (file.ToLower().EndsWith("mainfrom.cs"))
                        path = path + "";

                    if (file.ToLower().EndsWith(".cs") || file.ToLower().EndsWith(".java"))
                    {
                        StringTool.ProcessLogic(file, index + 1, LastCs == index++ - 100);  // 源码字符串混淆,选取一个源码文件中添加字符串解析类
                    }
                }

                MessageBox.Show("源码字符串混淆完成！");
            }
        }

        /// <summary>
        /// 获取listBox所有列表项信息
        /// </summary>
        private List<string> getList(ListBox listBox)
        {
            List<string> list = new List<string>();
            foreach (string iteam in listBox.Items)
            {
                if(!iteam.Equals("")) list.Add(iteam);
            }
            return list;
        }

        /// <summary>
        /// 获取listBox所有选中的列表项信息
        /// </summary>
        private List<string> getSelectedList(ListBox listBox)
        {
            List<string> list = new List<string>();


            foreach (object i in listBox.SelectedItems)
            {
                string text = i.ToString();
                list.Add(text);
            }
            return list;
        }

        /// <summary>
        /// 在listBox中显示list信息
        /// </summary>
        private void ShowInListBox(List<string> list, ListBox listBox)
        {
            listBox.Items.Clear();                          // 清空
            listBox.Items.AddRange(list.ToArray());         // 刷新显示
        }

        /// <summary>
        /// 添加from列表中的选中项到to列表中
        /// </summary>
        private void RemoveSelected(ListBox listBox)
        {
            List<string> list = getList(listBox);           // 获取所有列表项
            List<string> select = getSelectedList(listBox); // 获取选中项
            foreach (string text in select)                 // 移除选中项
            {
                if (list.Contains(text)) list.Remove(text);
            }

            ShowInListBox(list, listBox);                   // 在list列表中显示
        }

       

        /// <summary>
        /// 添加from列表中的选中项到to列表中
        /// </summary>
        private void AddSelectTo(ListBox from, ListBox to)
        {
            List<string> confuseList = getList(to);             // 获取混淆列表信息
            List<string> slectedList = getSelectedList(from);   // 获取所有字段中的选中项
            foreach (string text in slectedList)                // 添加至待混淆字段
            {
                if (!confuseList.Contains(text)) confuseList.Add(text);
            }

            ShowInListBox(confuseList, to);                     // 在list列表中显示
        }



        private void 添加至混淆字段ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSelectTo(listBoxAll, listBoxConfuse);    // 添加所有列表中的选中项到待混淆列表中
        }

        private void 添加至默认不混淆ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSelectTo(listBoxAll, listBoxExcept);     // 添加所有列表中的选中项到默认混淆列表中
            saveListBoxExcept();                        // 记录不混淆字段信息
        }

        private void 移除混淆字段ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemoveSelected(listBoxConfuse);             // 移除选中的不混淆字段
        }

        private void 移除至不混淆字段ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSelectTo(listBoxConfuse, listBoxExcept); // 添加至不混淆字段
            RemoveSelected(listBoxConfuse);             // 移除选中的混淆字段
            saveListBoxExcept();                        // 记录不混淆字段信息
        }

        private void 添加至待混淆字段ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSelectTo(listBoxExcept, listBoxConfuse); // 添加至待混淆字段
        }

        private void 移除选中项ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemoveSelected(listBoxExcept);              // 移除选中的混淆字段
            saveListBoxExcept();                        // 记录不混淆字段信息
        }

        /// <summary>
        /// 默认不混淆字段变动时，记录所有不混淆字段信息至注册表中
        /// </summary>
        private void saveListBoxExcept(List<string> list = null, string data = null)
        {
            list = getList(listBoxExcept);
            data = StringTool.ToEncodeSingleStr(list);   // 加密为单个串
            Registry.SaveValue("ExceptNameList", data);  // 保存
        }

        /// <summary>
        /// 载入默认不混淆列表信息
        /// </summary>
        private void loadExceptList(List<string> list = null, string data = null)
        {
            data = Registry.GetValue("ExceptNameList");
            list = StringTool.ToDecodeStrList(data);
            ShowInListBox(list, listBoxExcept);                // 在list列表中显示
        }

        /// <summary>
        /// 自动剔除包含在不混淆列表信息的待混淆项
        /// </summary>
        private void 剔除默认不混淆字段ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            autoClearExceptList();
        }

        /// <summary>
        /// 自动剔除包含在不混淆列表信息的待混淆项
        /// </summary>
        private void autoClearExceptList(List<string> listConfuse = null, List<string> listExcept = null)
        {
            listConfuse = getList(listBoxConfuse);
            listExcept = getList(listBoxExcept);
            foreach (string data in listExcept)
            {
                if (listConfuse.Contains(data)) listConfuse.Remove(data);
            }
            ShowInListBox(listConfuse, listBoxConfuse);        // 在list列表中显示
        }

        /// <summary>
        /// 检索，选中所有字段、待混淆字段
        /// </summary>
        bool SelectedIndexChanging = false;
        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SelectedIndexChanging) return;
            SelectedIndexChanging = true;

            ListBox cur = sender as ListBox;
            ListBox[] list = new ListBox[] { listBoxAll, listBoxConfuse, listBoxExcept };

            if (cur != null && cur.SelectedItem != null)
            {
                List<string> selected = getSelectedList(cur);
                foreach (ListBox box in list)
                {
                    if (box != cur) Search_Text(selected, box);
                }
            }

            SelectedIndexChanging = false;
        }

        /// <summary>
        /// 在listBox中选中texts对应项
        /// </summary>
        private void Search_Text(List<string> texts, ListBox list)
        {
            list.SelectedIndices.Clear();

            for (int i = list.Items.Count - 1; i >= 0; i--)
            {
                string curText = list.Items[i].ToString();
                bool march = texts.Contains(curText);

                if (march) list.SelectedIndices.Add(i);
            }
        }

    }
}
