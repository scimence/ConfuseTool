﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfuseTool
{
    public class ConfuseExe
    {
        public string path;                    // 文件路径
        public byte[] Bytes;                   // 文件数据信息
        public Dictionary<string, int> Dic;    // 名称索引映射信息
        public List<string> confuseList;       // 待混淆名称信息

        public ConfuseExe(string path)
        {
            this.path = path;
            Bytes = FileBinary.File2Bytes(path);                     // 获取Byte数据
            Dic = RenameTool.getStringsDic(Bytes);                   // 获取字符串和索引信息
            confuseList = RenameTool.getAssemblyStrings(path);       // 从Assembly反射获取待混淆的函数、变量名称
        }

        public ConfuseExe(string path, List<string> confuseList)
        {
            this.path = path;
            Bytes = FileBinary.File2Bytes(path);                     // 获取Byte数据
            Dic = RenameTool.getStringsDic(Bytes);                   // 获取字符串和索引信息
            //confuseList = RenameTool.getAssemblyStrings(path);       // 从Assembly反射获取待混淆的函数、变量名称
            this.confuseList = confuseList;                          
        }

        /// <summary>
        /// 执行名称混淆
        /// </summary>
        public void Confuse(bool saveNameInfo = false)
        {
            byte[] B = new byte[Bytes.Length];                            // 复制原有数据
            Array.Copy(Bytes, B, Bytes.Length);

            RenameTool.modify(B, Dic, confuseList);                       // 函数变量名称混淆
            FileBinary.Bytes2File(B, path.Replace(".exe", "_混淆.exe"));  // 保存

            if (saveNameInfo)
            {
                String names = "\r\n所有字段：\r\n" + RenameTool.getNames(Dic) + "\r\n\r\n已混淆字段：\r\n" + RenameTool.getNames(confuseList);   // 获取所有strings信息
                FileTool.SaveProcess(names, path.Replace(".exe", "_exe.txt"), null, true);          // 保存为文件
            }
        }

        /// <summary>
        /// 在list列表中显示，所有字段、待混淆字段
        /// </summary>
        public void showInList(ListBox listAll, ListBox listConfuse)
        {
            listAll.Items.Clear();
            listAll.Items.AddRange(Dic.Keys.ToArray());

            listConfuse.Items.Clear();
            listConfuse.Items.AddRange(confuseList.ToArray());
        }
    }

    class RenameTool
    {
        /// <summary>
        /// 获取混淆列表信息，从listConfuse中移除默认不混淆字段
        /// </summary>
        private static List<string> removeExceptionList(List<string> listConfuse, List<string> listExcept = null, string data0 = null)
        {
            data0 = Registry.GetValue("ExceptNameList");
            listExcept = StringTool.ToDecodeStrList(data0);

            foreach (string data in listExcept)
            {
                if (listConfuse.Contains(data)) listConfuse.Remove(data);
            }

            return listConfuse;
        }

        /// <summary>
        /// 对给定的文件进行混淆
        /// </summary>
        public static void ProcessLogic(string path, bool saveNameInfo = false)
        {
            try
            {
                byte[] B = FileBinary.File2Bytes(path);                         // 获取Byte数据

                Dictionary<string, int> Dic = getStringsDic(B);                 // 获取字符串和索引信息
                List<string> assemblyList = getAssemblyStrings(path);           // 从Assembly反射获取待混淆的函数、变量名称
                assemblyList = removeExceptionList(assemblyList);               // 移除混淆列表中的默认不混淆字段

                modify(B, Dic, assemblyList);                                   // 函数变量名称混淆

                FileBinary.Bytes2File(B, path.Replace(".exe", "_confuse.exe")); // 保存

                if (saveNameInfo)
                {
                    String names = "\r\n所有字段：\r\n" + getNames(Dic) + "\r\n\r\n已混淆字段：\r\n" + getNames(assemblyList);   // 获取所有strings信息
                    FileTool.SaveProcess(names, path.Replace(".exe", "_exe.txt"), null, true);          // 保存为文件
                }
            }
            catch (Exception) { }
        }

        /// <summary>
        /// 获取所有名称信息
        /// </summary>
        public static string getNames(Dictionary<string, int> Dic)
        {
            StringBuilder Str = new StringBuilder();
            Str.AppendLine(Dic.Keys.Count + "项");
            foreach (string name in Dic.Keys)
            {
                Str.AppendLine(name);
            }
            return Str.ToString();
        }

        /// <summary>
        /// 获取所有名称信息
        /// </summary>
        public static string getNames(List<string> assemblyList)
        {
            StringBuilder Str = new StringBuilder();
            Str.AppendLine(assemblyList.Count + "项");
            foreach (string name in assemblyList)
            {
                Str.AppendLine(name);
            }
            return Str.ToString();
        }

        /// <summary>
        /// 获取Strings信息
        /// </summary>
        public static Dictionary<string, int> getStringsDic(byte[] B)
        {
            Dictionary<string, int> list = new Dictionary<string, int>();

            bool containsModule = false;
            List<byte> Str = new List<byte>();
            int index = 0;
            for (int i = 0; i < B.Length; i++)
            {
                if (B[i] == 0 && Str.Count != 0)
                {
                    String S = Encoding.UTF8.GetString(Str.ToArray());
                    if (containsModule && S.Equals("\0")) containsModule = false;
                    else
                    {
                        if (containsModule && !list.ContainsKey(S)) list.Add(S, index + 1);

                        if (S.Equals("<Module>"))
                        {
                            list.Clear();           // 清除之前的
                            containsModule = true;
                        }
                    }

                    Str.Clear();
                }
                else Str.Add(B[i]);
                if (B[i] == 0) index = i;
            }

            return list;
        }

        /// <summary>
        /// 获取Strings信息
        /// </summary>
        public static List<string> getStrings(byte[] B)
        {
            List<string> list = new List<string>();

            bool containsModule = false;
            List<byte> Str = new List<byte>();
            foreach (byte b in B)
            {
                if (b == 0 && Str.Count != 0)
                {
                    String S = Encoding.UTF8.GetString(Str.ToArray());
                    if (containsModule && S.Equals("\0")) break;
                    if (containsModule && !list.Contains(S)) list.Add(S);
                    if (S.Equals("<Module>")) containsModule = true;

                    Str.Clear();
                }
                else Str.Add(b);
            }

            return list;
        }

        /// <summary>
        /// 从Assembly解析函数、变量名称
        /// </summary>
        public static List<string> getAssemblyStrings(string path)
        {
            Assembly asssembly = Assembly.LoadFile(path);

            List<string> list = new List<string>();

            Type[] types = asssembly.GetTypes();
            foreach (Type type in types)
            {
                if (type.Name.Equals("Settings")) continue;     // 不混淆Settings

                list.Add(type.Name);

                foreach (MethodInfo method in type.GetMethods(BindingFlags.DeclaredOnly & (BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)))
                {
                    String ClassName = method.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(method.Name))
                    {
                        list.Add(method.Name);

                        // 添加参数变量
                        //ParameterInfo[] param = method.GetParameters();
                        //foreach (ParameterInfo p in param)
                        //{
                        //    if (!list.Contains(p.Name))
                        //        list.Add(p.Name);
                        //}

                    }
                }

                foreach (FieldInfo field in type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
                {
                    String ClassName = field.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(field.Name)) list.Add(field.Name);
                }

                foreach (MemberInfo member in type.GetMembers(BindingFlags.DeclaredOnly & (BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)))
                {
                    String ClassName = member.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(member.Name)) list.Add(member.Name);
                }

                foreach (PropertyInfo info in type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
                {
                    String ClassName = info.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(info.Name)) list.Add(info.Name);
                }

                foreach (EventInfo info in type.GetEvents(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
                {
                    String ClassName = info.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(info.Name)) list.Add(info.Name);
                }


                foreach (FieldInfo field in type.GetRuntimeFields())
                {
                    String ClassName = field.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(field.Name)) list.Add(field.Name);
                }

                foreach (MethodInfo field in type.GetRuntimeMethods())
                {
                    String ClassName = field.DeclaringType.Name;
                    if (!field.IsVirtual && ClassName.Equals(type.Name) && !list.Contains(field.Name))
                    {
                        list.Add(field.Name);
                        //if (field.Name.Equals("Process")) 
                        //    ClassName = "";

                        // 添加参数变量
                        ParameterInfo[] param = field.GetParameters();
                        foreach (ParameterInfo p in param)
                        {

                            if (!list.Contains(p.Name))
                                list.Add(p.Name);
                        }

                        //// 获取方法内部变量名称
                        //MethodBody body = field.GetMethodBody();
                        //foreach (LocalVariableInfo l in body.LocalVariables)
                        //{
                        //    Type ty = l.GetType();
                        //    Type tyL = l.LocalType;

                        //    PropertyInfo[] info = tyL.GetProperties();
                        //    object value = info.GetValue(0);

                        //    string name = l.ToString();
                        //    string name1 = l.GetType().Name;
                        //    string name2 = l.LocalType.Name;
                        //    //string name3 = .

                        //    if (!list.Contains(l.GetType().Name))
                        //        list.Add(l.LocalType.Name);
                        //}

                    }
                }

                foreach (EventInfo field in type.GetRuntimeEvents())
                {
                    String ClassName = field.DeclaringType.Name;
                    if (ClassName.Equals(type.Name) && !list.Contains(field.Name)) list.Add(field.Name);
                }
            }

            //if (list.Contains("components")) list.Remove("components");
            //if (list.Contains("Resources")) list.Remove("Resources");
            //if (list.Contains("Culture")) list.Remove("Culture");
            //if (list.Contains("get_ResourceManager")) list.Remove("get_ResourceManager");
            //if (list.Contains("get_Culture")) list.Remove("get_Culture");
            //if (list.Contains("set_Culture")) list.Remove("set_Culture");
            //if (list.Contains("get_Update")) list.Remove("get_Update");
            if (list.Contains("ResourceManager")) list.Remove("ResourceManager");
            //if (list.Contains("resourceCulture")) list.Remove("resourceCulture");
            //if (list.Contains("resourceMan")) list.Remove("resourceMan");
            //if (list.Contains("Update")) list.Remove("Update");
            //if (list.Contains("replace")) list.Remove("replace");
            //if (list.Contains("components")) list.Remove("components");
            //if (list.Contains("InitializeComponent")) list.Remove("InitializeComponent");
            
            
            return list;
        }

        /// <summary>
        /// 函数变量名称混淆
        /// </summary>
        public static void modify(byte[] B, Dictionary<string, int> Dic, List<string> assemblyList = null)
        {
            if (assemblyList == null) assemblyList = Dic.Keys.ToList();
            foreach (string key in assemblyList)
            {
                if (Dic.ContainsKey(key))
                {
                    int index = Dic[key];
                    byte[] A = Encoding.UTF8.GetBytes(key);
                    for (int i = 0; i < A.Length; i++)
                    {
                        B[index + i] = TransByte(A[i]); 
                    }
                }
            }
        }

        /// <summary>
        /// 函数变量名称混淆
        /// </summary>
        public static void modify(byte[] B, Dictionary<string, int> Dic, string key)
        {
            if (!Dic.ContainsKey(key)) return;
            int index = Dic[key];
            byte[] A = Encoding.UTF8.GetBytes(key);
            for (int i = 0; i < A.Length; i++ )
            {
                B[index + i] = TransByte(A[i]);
            }
        }

        /// <summary>
        /// 混淆映射
        /// </summary>
        private static byte TransByte(byte b)
        {
            int n = b - 61;
            if (n < 1) n = n + 255;

            return reByte(n);
        }


        private static Dictionary<int, byte> reByteDic = new Dictionary<int, byte>();   // 存储重编码映射信息
        /// <summary>
        /// 对byte值进行重编码映射，使得原有0-255散列映射到其区间
        /// </summary>
        private static byte reByte(int b)
        {
            if (!reByteDic.ContainsKey(b))
            {
                List<bool> list = ToBool((int)b);
                int n = 0;
                for (int i = 6; i >= 0; i = i - 2)
                {
                    n = n << 1;
                    n = n | (list[i] ? 1 : 0);
                }

                for (int i = 1; i < 8; i = i + 2)
                {
                    n = n << 1;
                    n = n | (list[i] ? 1 : 0);
                }

                reByteDic.Add(b, (byte)n);
            }

            return reByteDic[b];
        }

        /// <summary>
        /// 获取各位bool值
        /// </summary>
        private static List<bool> ToBool(int B)
        {
            List<bool> list = new List<bool>();
            for (int i = 0; i < 8; i++)
            {
                bool b = ((B & 1) == 1);
                B = B >> 1;
                list.Add(b);
            }
            return list;
        }

        /// <summary>
        /// 逆混淆映射
        /// </summary>
        private static byte reTransByte(byte b)
        {
            int n = b + 70;
            if (n > 254) n = n - 255;
            return (byte)n;
        }

    }
}
