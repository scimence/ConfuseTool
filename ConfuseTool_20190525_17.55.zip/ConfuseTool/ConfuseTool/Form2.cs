﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfuseTool
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void text_files_DragDrop(object sender, DragEventArgs e)
        {
            DragDropTool.Form_DragDrop(sender, e);
        }

        private void text_files_DragEnter(object sender, DragEventArgs e)
        {
            DragDropTool.Form_DragEnter(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] files = text_files.Text.Split(';');
            List<string> tmp = SrcCodeTool.GetFileCodeNames(files);

            String count = tmp.Count + "";
        }

    }
}
