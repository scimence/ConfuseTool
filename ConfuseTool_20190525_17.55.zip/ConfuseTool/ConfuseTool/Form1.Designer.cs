﻿namespace ConfuseTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxPath = new System.Windows.Forms.TextBox();
            this.checkBox = new System.Windows.Forms.CheckBox();
            this.button = new System.Windows.Forms.Button();
            this.contextMenuAll = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.添加至混淆字段ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加至默认不混淆ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuConfuse = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.移除混淆字段ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加至不混淆字段ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.剔除默认不混淆字段ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxAll = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxConfuse = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listBoxExcept = new System.Windows.Forms.ListBox();
            this.contextMenuExcept = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.添加至待混淆字段ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.移除此项ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonStr = new System.Windows.Forms.Button();
            this.contextMenuAll.SuspendLayout();
            this.contextMenuConfuse.SuspendLayout();
            this.contextMenuExcept.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxPath
            // 
            this.textBoxPath.AllowDrop = true;
            this.textBoxPath.Location = new System.Drawing.Point(12, 12);
            this.textBoxPath.Multiline = true;
            this.textBoxPath.Name = "textBoxPath";
            this.textBoxPath.Size = new System.Drawing.Size(529, 21);
            this.textBoxPath.TabIndex = 1;
            this.textBoxPath.Text = "拖动待vs工程根目录至此\r\n";
            this.textBoxPath.DragDrop += new System.Windows.Forms.DragEventHandler(this.Form1_DragDropProject);
            this.textBoxPath.DragEnter += new System.Windows.Forms.DragEventHandler(this.Form1_DragEnter);
            // 
            // checkBox
            // 
            this.checkBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox.AutoSize = true;
            this.checkBox.Location = new System.Drawing.Point(12, 319);
            this.checkBox.Name = "checkBox";
            this.checkBox.Size = new System.Drawing.Size(114, 16);
            this.checkBox.TabIndex = 2;
            this.checkBox.Text = "输出Strings信息";
            this.checkBox.UseVisualStyleBackColor = true;
            // 
            // button
            // 
            this.button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button.Location = new System.Drawing.Point(466, 315);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 7;
            this.button.Text = "混淆exe";
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.button_Click);
            // 
            // contextMenuAll
            // 
            this.contextMenuAll.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加至混淆字段ToolStripMenuItem,
            this.添加至默认不混淆ToolStripMenuItem});
            this.contextMenuAll.Name = "contextMenuAll";
            this.contextMenuAll.Size = new System.Drawing.Size(173, 48);
            // 
            // 添加至混淆字段ToolStripMenuItem
            // 
            this.添加至混淆字段ToolStripMenuItem.Name = "添加至混淆字段ToolStripMenuItem";
            this.添加至混淆字段ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.添加至混淆字段ToolStripMenuItem.Text = "添加至混淆字段";
            this.添加至混淆字段ToolStripMenuItem.Click += new System.EventHandler(this.添加至混淆字段ToolStripMenuItem_Click);
            // 
            // 添加至默认不混淆ToolStripMenuItem
            // 
            this.添加至默认不混淆ToolStripMenuItem.Name = "添加至默认不混淆ToolStripMenuItem";
            this.添加至默认不混淆ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.添加至默认不混淆ToolStripMenuItem.Text = "添加至默认不混淆";
            this.添加至默认不混淆ToolStripMenuItem.Click += new System.EventHandler(this.添加至默认不混淆ToolStripMenuItem_Click);
            // 
            // contextMenuConfuse
            // 
            this.contextMenuConfuse.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.移除混淆字段ToolStripMenuItem,
            this.添加至不混淆字段ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.剔除默认不混淆字段ToolStripMenuItem});
            this.contextMenuConfuse.Name = "contextMenuConfuse";
            this.contextMenuConfuse.Size = new System.Drawing.Size(185, 76);
            // 
            // 移除混淆字段ToolStripMenuItem
            // 
            this.移除混淆字段ToolStripMenuItem.Name = "移除混淆字段ToolStripMenuItem";
            this.移除混淆字段ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.移除混淆字段ToolStripMenuItem.Text = "移除选中混淆字段";
            this.移除混淆字段ToolStripMenuItem.Click += new System.EventHandler(this.移除混淆字段ToolStripMenuItem_Click);
            // 
            // 添加至不混淆字段ToolStripMenuItem
            // 
            this.添加至不混淆字段ToolStripMenuItem.Name = "添加至不混淆字段ToolStripMenuItem";
            this.添加至不混淆字段ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.添加至不混淆字段ToolStripMenuItem.Text = "移除至不混淆字段";
            this.添加至不混淆字段ToolStripMenuItem.Click += new System.EventHandler(this.移除至不混淆字段ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(181, 6);
            // 
            // 剔除默认不混淆字段ToolStripMenuItem
            // 
            this.剔除默认不混淆字段ToolStripMenuItem.Name = "剔除默认不混淆字段ToolStripMenuItem";
            this.剔除默认不混淆字段ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.剔除默认不混淆字段ToolStripMenuItem.Text = "剔除默认不混淆字段";
            this.剔除默认不混淆字段ToolStripMenuItem.Click += new System.EventHandler(this.剔除默认不混淆字段ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 12;
            this.label1.Text = "所有字段：";
            // 
            // listBoxAll
            // 
            this.listBoxAll.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxAll.ContextMenuStrip = this.contextMenuAll;
            this.listBoxAll.FormattingEnabled = true;
            this.listBoxAll.HorizontalScrollbar = true;
            this.listBoxAll.ItemHeight = 12;
            this.listBoxAll.Location = new System.Drawing.Point(9, 72);
            this.listBoxAll.Name = "listBoxAll";
            this.listBoxAll.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxAll.Size = new System.Drawing.Size(174, 232);
            this.listBoxAll.Sorted = true;
            this.listBoxAll.TabIndex = 11;
            this.listBoxAll.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "待混淆字段：";
            // 
            // listBoxConfuse
            // 
            this.listBoxConfuse.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxConfuse.ContextMenuStrip = this.contextMenuConfuse;
            this.listBoxConfuse.FormattingEnabled = true;
            this.listBoxConfuse.HorizontalScrollbar = true;
            this.listBoxConfuse.ItemHeight = 12;
            this.listBoxConfuse.Location = new System.Drawing.Point(187, 72);
            this.listBoxConfuse.Name = "listBoxConfuse";
            this.listBoxConfuse.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxConfuse.Size = new System.Drawing.Size(174, 232);
            this.listBoxConfuse.Sorted = true;
            this.listBoxConfuse.TabIndex = 13;
            this.listBoxConfuse.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "默认不混淆字段：";
            // 
            // listBoxExcept
            // 
            this.listBoxExcept.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxExcept.ContextMenuStrip = this.contextMenuExcept;
            this.listBoxExcept.FormattingEnabled = true;
            this.listBoxExcept.HorizontalScrollbar = true;
            this.listBoxExcept.ItemHeight = 12;
            this.listBoxExcept.Location = new System.Drawing.Point(367, 72);
            this.listBoxExcept.Name = "listBoxExcept";
            this.listBoxExcept.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxExcept.Size = new System.Drawing.Size(174, 232);
            this.listBoxExcept.Sorted = true;
            this.listBoxExcept.TabIndex = 15;
            this.listBoxExcept.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // contextMenuExcept
            // 
            this.contextMenuExcept.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加至待混淆字段ToolStripMenuItem,
            this.移除此项ToolStripMenuItem});
            this.contextMenuExcept.Name = "contextMenuExcept";
            this.contextMenuExcept.Size = new System.Drawing.Size(173, 48);
            // 
            // 添加至待混淆字段ToolStripMenuItem
            // 
            this.添加至待混淆字段ToolStripMenuItem.Name = "添加至待混淆字段ToolStripMenuItem";
            this.添加至待混淆字段ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.添加至待混淆字段ToolStripMenuItem.Text = "添加至待混淆字段";
            this.添加至待混淆字段ToolStripMenuItem.Click += new System.EventHandler(this.添加至待混淆字段ToolStripMenuItem_Click);
            // 
            // 移除此项ToolStripMenuItem
            // 
            this.移除此项ToolStripMenuItem.Name = "移除此项ToolStripMenuItem";
            this.移除此项ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.移除此项ToolStripMenuItem.Text = "移除选中项";
            this.移除此项ToolStripMenuItem.Click += new System.EventHandler(this.移除选中项ToolStripMenuItem_Click);
            // 
            // buttonStr
            // 
            this.buttonStr.Location = new System.Drawing.Point(362, 315);
            this.buttonStr.Name = "buttonStr";
            this.buttonStr.Size = new System.Drawing.Size(98, 23);
            this.buttonStr.TabIndex = 17;
            this.buttonStr.Text = "混淆源码字符串";
            this.buttonStr.UseVisualStyleBackColor = true;
            this.buttonStr.Click += new System.EventHandler(this.buttonStr_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 345);
            this.Controls.Add(this.buttonStr);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBoxExcept);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxConfuse);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxAll);
            this.Controls.Add(this.button);
            this.Controls.Add(this.checkBox);
            this.Controls.Add(this.textBoxPath);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ConfuseRename";
            this.contextMenuAll.ResumeLayout(false);
            this.contextMenuConfuse.ResumeLayout(false);
            this.contextMenuExcept.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPath;
        private System.Windows.Forms.CheckBox checkBox;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.ContextMenuStrip contextMenuAll;
        private System.Windows.Forms.ContextMenuStrip contextMenuConfuse;
        private System.Windows.Forms.ToolStripMenuItem 添加至混淆字段ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 移除混淆字段ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxAll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxConfuse;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBoxExcept;
        private System.Windows.Forms.ToolStripMenuItem 添加至默认不混淆ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加至不混淆字段ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuExcept;
        private System.Windows.Forms.ToolStripMenuItem 添加至待混淆字段ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 移除此项ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 剔除默认不混淆字段ToolStripMenuItem;
        private System.Windows.Forms.Button buttonStr;
    }
}